#!/bin/bash

echo "🚀 Iniciando Backend Torneos..."

# Limpiar y compilar
echo "📦 Compilando proyecto..."
mvn clean compile

# Ejecutar aplicación
echo "🔥 Ejecutando aplicación en puerto 8082..."
mvn spring-boot:run -Dspring.profiles.active=postgres &

# Esperar que inicie
echo "⏳ Esperando que la aplicación inicie..."
sleep 15

# Probar APIs básicas
echo "🧪 Probando APIs..."

echo "1. Health Check:"
curl -s http://localhost:8082/api/health | jq .

echo -e "\n2. Swagger UI disponible en: http://localhost:8082/swagger-ui.html"

echo -e "\n3. Categorías:"
curl -s http://localhost:8082/api/categories | jq .

echo -e "\n4. Tipos de juego:"
curl -s http://localhost:8082/api/game-types | jq .

echo -e "\n✅ Pruebas básicas completadas"
echo "📋 Ver documento completo: doc/PLAN_PRUEBAS_APIS.md"