package com.example.torneos.application.dto.request;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.UUID;

public record CreateTournamentRequest(
    UUID categoryId,
    UUID gameTypeId,
    String name,
    String description,
    Boolean isPaid,
    Integer maxFreeCapacity,
    LocalDateTime startDateTime,
    LocalDateTime endDateTime
) {}